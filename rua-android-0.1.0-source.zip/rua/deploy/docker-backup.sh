#!/bin/sh
set -eu
# Uso: ./deploy/docker-backup.sh [directorio-destino]
DEST="${1:-./backups}"
mkdir -p "$DEST"
STAMP="$(date +%Y%m%d-%H%M%S)"
docker run --rm -v rua-data:/data -v "$PWD/$DEST:/backup" alpine:3.20 \
  tar -czf "/backup/rua-data-$STAMP.tar.gz" -C /data .
printf 'Copia creada: %s/rua-data-%s.tar.gz\n' "$DEST" "$STAMP"
