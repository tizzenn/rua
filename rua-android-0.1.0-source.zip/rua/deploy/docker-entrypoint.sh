#!/bin/sh
set -eu
mkdir -p "${RUA_CONFIG_DIR:-/data}"
for file in instance.json sources.json categories.json; do
  if [ ! -f "${RUA_CONFIG_DIR:-/data}/$file" ]; then
    cp "/app/$file" "${RUA_CONFIG_DIR:-/data}/$file"
  fi
done
exec "$@"
