"""Pruebas locales: python -m unittest discover -s tests"""
import os, sys, json, tempfile, threading, unittest, urllib.request, urllib.error
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import date, timedelta
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ["RUA_DB"] = str(Path(tempfile.mkdtemp()) / "t.sqlite3")
os.environ["RUA_ADMIN_TOKEN"] = "t" * 32
import core, collector, push, server  # noqa
from unittest.mock import patch

F = (date.today() + timedelta(days=30)).strftime("%Y%m%d")
ICS = f"""BEGIN:VCALENDAR\r
BEGIN:VEVENT\r
SUMMARY:Noche de rap gallego\r
DTSTART;VALUE=DATE:{F}\r
LOCATION:Sala Capitol\\, Santiago de Compostela\r
URL:https://example.com/e1\r
END:VEVENT\r
BEGIN:VEVENT\r
SUMMARY:Concierto de jazz\r
DTSTART;VALUE=DATE:{F}\r
LOCATION:Vigo\r
END:VEVENT\r
BEGIN:VEVENT\r
SUMMARY:Trap night\r
DTSTART;VALUE=DATE:{F}\r
LOCATION:A Coruña\r
END:VEVENT\r
BEGIN:VEVENT\r
SUMMARY:DJ session drill\r
DTSTART;VALUE=DATE:20200101\r
LOCATION:Vigo\r
END:VEVENT\r
END:VCALENDAR\r
""".encode()


class Feed(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200); self.end_headers(); self.wfile.write(ICS)
    def log_message(self, *a): pass


class T(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        core.init_db()
        cls.feed = HTTPServer(("127.0.0.1", 0), Feed)
        threading.Thread(target=cls.feed.serve_forever, daemon=True).start()
        cls.api = server.ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        threading.Thread(target=cls.api.serve_forever, daemon=True).start()
        cls.base = f"http://127.0.0.1:{cls.api.server_port}"

    def req(self, path, data=None, token=None, method=None):
        r = urllib.request.Request(self.base + path, data=json.dumps(data).encode() if data is not None else None,
                                   headers={"Content-Type": "application/json", **({"Authorization": f"Bearer {token}"} if token else {})}, method=method)
        try:
            with urllib.request.urlopen(r) as x: return x.status, x.read()
        except urllib.error.HTTPError as e: return e.code, e.read()

    def test_1_no_leaks(self):
        for p in ("/rua.sqlite3", "/server.py", "/core.py", "/vapid_private.pem", "/../server.py"):
            self.assertNotEqual(self.req(p)[0], 200, p)
        self.assertEqual(self.req("/index.html")[0], 200)

    def test_2_collector(self):
        src = {"name": "Test", "type": "ics", "url": f"http://127.0.0.1:{self.feed.server_port}/x.ics", "status": "announced"}
        evs = [to for to in (collector.to_event(i, src) for i in collector.collect(src))]
        ok = [e for e, _ in evs if e]
        self.assertEqual(len(ok), 1)
        self.assertEqual((ok[0]["city"], ok[0]["style"]), ("Santiago de Compostela", "Rap gallego"))
        self.assertEqual([w for e, w in evs if not e], ["estilo no acreditado ni artista catalogado", "localidad no incluida o no verificable", "pasado"])

    def test_3_catalog_and_geographic_guard(self):
        event = {"title": "Hard GZ - gira 2027", "text": "", "place": "Sala en Vigo",
                 "date": F[:4] + "-" + F[4:6] + "-" + F[6:], "url": "https://example.com/hardgz",
                 "announced_at": "", "presale_at": ""}
        ev, why = collector.to_event(event, {"name": "Agenda", "type": "ics", "url": "https://example.com", "status": "announced"})
        self.assertIsNone(why)
        self.assertEqual(ev["artist"], "Hard GZ")
        self.assertEqual(ev["status"], "announced")
        self.assertIn("turismo.gal", ev["style_source_url"])
        self.assertEqual(ev["announced_at"], "")
        wrong = {**event, "place": "Sala Queen, Mos", "text": "Vigo"}
        ev, why = collector.to_event(wrong, {"name": "Agenda", "type": "ics", "url": "https://example.com", "status": "announced"})
        self.assertIsNone(ev)
        self.assertEqual(why, "localidad no incluida o no verificable")

    def test_4_cultura_api_mapping(self):
        payload = {"totalResultados": 1, "elementosPorPaxina": 25, "listaAxenda": [{
            "titulo": "Hard GZ — directo", "corpo": "Concierto de rap", "entrada": "",
            "concello": "Vigo", "lugarCelebracion": "Auditorio", "tipoEvento": "Concerto",
            "data": {"dataInicio": "2030-05-12 21:00:00"},
            "ligazons": [{"titulo": "Información", "url": "https://cultura.gal/evento/1"},
                         {"titulo": "Entradas", "url": "https://tickets.example/1"}]
        }]}
        with patch.object(collector, "fetch_post_form", return_value=payload):
            items = list(collector.read_cultura_api({"url": "https://www.cultura.gal/services/abertos",
                    "councils": {"Vigo": 502}, "days_ahead": 365}))
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["date"], "2030-05-12")
        self.assertEqual(items[0]["ticket_url"], "https://tickets.example/1")
        ev, why = collector.to_event(items[0], {"name": "Axenda API", "status": "announced"})
        self.assertIsNone(why)
        self.assertEqual(ev["city"], "Vigo")
        self.assertEqual(ev["announced_at"], "")

    def test_5_concertos_xacobeo_api_mapping(self):
        payload = {"total_pages": 1, "events": [{
            "title": "Hard GZ", "description": "Concierto", "url": "https://concertosdoxacobeo.gal/es/evento/hard-gz/",
            "start_date": "2030-06-20 22:30:00", "venue": {"venue": "Sala", "address": "Rúa", "city": "Vigo"},
            "ticket_url": "https://tickets.example/hardgz"
        }]}
        with patch.object(collector, "fetch", return_value=__import__("json").dumps(payload).encode()):
            items = list(collector.read_tribe_api({"url": "https://concertosdoxacobeo.gal/wp-json/tribe/events/v1/events"}))
        self.assertEqual(items[0]["place"], "Sala Rúa Vigo")
        ev, why = collector.to_event(items[0], {"name": "Concertos do Xacobeo", "status": "announced"})
        self.assertIsNone(why)
        self.assertEqual(ev["city"], "Vigo")
        self.assertEqual(ev["status"], "announced")

    def test_6_dedupe_and_rss(self):
        base = {"artist": "Artista X", "city": "Vigo", "date": F[:4] + "-" + F[4:6] + "-" + F[6:], "style": "Rap"}
        a, c1 = core.upsert_event({**base, "venue": ""}); b, c2 = core.upsert_event({**base, "venue": "Sala Rouge", "status": "confirmed"})
        self.assertEqual((a, c1, c2), (b, True, False))
        with core.connect() as db:
            row = db.execute("SELECT venue,status FROM events WHERE id=?", (a,)).fetchone()
        self.assertEqual((row["venue"], row["status"]), ("Sala Rouge", "confirmed"))
        import xml.etree.ElementTree as ET
        root = ET.fromstring(core.rss_feed())
        from email.utils import parsedate_to_datetime
        self.assertIsNotNone(parsedate_to_datetime(root.find("channel/item/pubDate").text).tzinfo)

    def test_4_validation_and_auth(self):
        bad = {"artist": "X", "city": "A Coruña", "date": "2030-01-01", "style": "Rap"}
        self.assertEqual(self.req("/api/events", bad, "t" * 32)[0], 400)
        self.assertEqual(self.req("/api/events", bad)[0], 403)
        self.assertEqual(self.req("/api/events", bad, "x" * 32)[0], 403)

    def test_5_push_endpoints(self):
        self.assertEqual(self.req("/api/push/key")[0], 503)  # sin claves
        sub = {"endpoint": "https://push.example/abc", "keys": {"p256dh": "k", "auth": "a"}}
        self.assertEqual(self.req("/api/push/subscribe", sub)[0], 201)
        self.assertEqual(self.req("/api/push/subscribe", {**sub, "endpoint": "http://x"})[0], 400)
        self.assertEqual(self.req("/api/push/unsubscribe", sub)[0], 200)

    def test_6_notify_marks_once(self):
        push.notify_new(mark_only=True)
        with core.connect() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM events WHERE notified_at IS NULL").fetchone()[0], 0)

    def test_7_city_matching_is_strict(self):
        self.assertEqual(collector.classify("Hard GZ en concierto", "Sala Capitol, Santiago de Compostela")[0], "Santiago de Compostela")
        self.assertIsNone(collector.classify("Concierto en Santiago", "Teatro en Santiago de Chile")[0])
        self.assertIsNone(collector.classify("Gira por Vigo", "Sala Queen, Mos")[0])
        self.assertIsNone(collector.classify("Rap en Vigo y Ourense", "")[0])
        self.assertIsNone(collector.classify("Concierto", "Sala en A Coruña, Vigo")[0])

    def test_8_status_never_downgrades(self):
        base = {"artist": "Estado Test", "city": "Vigo", "date": F[:4] + "-" + F[4:6] + "-" + F[6:], "style": "Rap"}
        eid, created = core.upsert_event({**base, "status": "confirmed", "source_url": "https://official.example/event"})
        self.assertTrue(created)
        core.upsert_event({**base, "status": "announced", "source_url": "https://aggregator.example/event"})
        with core.connect() as db:
            row = db.execute("SELECT status FROM events WHERE id=?", (eid,)).fetchone()
        self.assertEqual(row["status"], "confirmed")

    def test_9_rejects_unsafe_event_urls(self):
        base = {"artist": "URL Test", "city": "Vigo", "date": F[:4] + "-" + F[4:6] + "-" + F[6:], "style": "Rap"}
        with self.assertRaises(ValueError):
            core.validate_event({**base, "source_url": "javascript:alert(1)"})
        with self.assertRaises(ValueError):
            core.validate_event({**base, "ticket_url": "http://tickets.example/event"})

    def test_10_source_health_history(self):
        name = "Axenda test de salud"
        core.record_source_run(name, "rss", "error", error="timeout")
        row = next(x for x in core.get_source_status() if x["name"] == name) if any(x["name"] == name for x in core.get_source_status()) else None
        self.assertIsNone(row)  # las fuentes no configuradas no se publican
        core.record_source_run("Axenda de Cultura de Galicia — RSS oficial", "rss", "error", error="timeout")
        row = next(x for x in core.get_source_status() if x["name"] == "Axenda de Cultura de Galicia — RSS oficial")
        self.assertEqual((row["status"], row["error"]), ("error", "timeout"))

    def test_11_status_endpoint(self):
        status, raw = self.req("/api/status")
        self.assertEqual(status, 200)
        payload = json.loads(raw)
        self.assertIn("sources", payload)
        self.assertGreaterEqual(payload["enabled"], 1)

    def test_12_multi_artist_catalog_and_aliases(self):
        title = "Hard GZ + Boyanka Kostova en directo"
        matches = collector.artist_matches(title)
        self.assertEqual([a["name"] for a in matches], ["Hard GZ", "Boyanka Kostova"])
        self.assertEqual(collector.artist_matches("Lil GZ"), [])  # no es alias de Hard GZ
        self.assertEqual(collector.artist_matches("Hardgz" )[0]["name"], "Hard GZ")
        event = {"title": title, "text": "Con la colaboración de Arce", "place": "Sala en Vigo",
                 "date": F[:4] + "-" + F[4:6] + "-" + F[6:], "url": "https://example.com/multi"}
        ev, why = collector.to_event(event, {"name": "Agenda", "status": "announced", "page": "https://example.com"})
        self.assertIsNone(why)
        self.assertEqual(ev["artist"], "Hard GZ & Boyanka Kostova")
        self.assertNotIn("Arce", ev["artist"])

    def test_13_catalog_entries_have_evidence(self):
        artists = collector.load_artists()
        self.assertGreaterEqual(len(artists), 50)
        self.assertEqual(len({a["name"].casefold() for a in artists}), len(artists))
        for artist in artists:
            self.assertTrue(artist["styles"], artist["name"])
            self.assertTrue(artist["style_source_url"].startswith("https://"), artist["name"])

    def test_14_jsonld_event_parser(self):
        html = '''<html><script type="application/ld+json">{
          "@context":"https://schema.org","@graph":[{
            "@type":"MusicEvent","name":"Directo en Vigo","startDate":"2030-07-21T21:00:00+02:00",
            "url":"https://events.example/hardgz",
            "location":{"@type":"Place","name":"Sala Queen","address":{"@type":"PostalAddress","streetAddress":"Rúa Example 1","addressLocality":"Vigo","addressRegion":"Pontevedra"}},
            "performer":[{"@type":"MusicGroup","name":"Hard GZ"},{"@type":"MusicGroup","name":"Boyanka Kostova"}],
            "offers":{"@type":"Offer","url":"https://tickets.example/hardgz"}
          }]}</script></html>'''.encode('utf-8')
        items = list(collector.read_jsonld(html))
        self.assertEqual(len(items), 1)
        self.assertIn("Hard GZ", items[0]["title"])
        self.assertIn("Boyanka Kostova", items[0]["title"])
        self.assertIn("Vigo", items[0]["place"])
        self.assertNotIn("Pontevedra", items[0]["place"])
        self.assertEqual(items[0]["date"], "2030-07-21")
        self.assertEqual(items[0]["ticket_url"], "https://tickets.example/hardgz")
        ev, why = collector.to_event(items[0], {"name":"JSON-LD", "status":"unverified", "page":"https://events.example"})
        self.assertIsNone(why)
        self.assertEqual(ev["artist"], "Hard GZ & Boyanka Kostova")
        self.assertEqual(ev["city"], "Vigo")



    def test_15_generic_activity_multiple_categories_and_entities(self):
        starts = (date.today() + timedelta(days=60)).isoformat() + "T18:30:00+01:00"
        payload = {"title": "Ruta solidaria", "municipality": "Ourense", "starts_at": starts,
                   "category_ids": ["deporte", "voluntariado"], "status": "scheduled",
                   "verification": "official", "announced_at": (date.today() - timedelta(days=2)).isoformat(),
                   "registration_opens_at": (date.today() + timedelta(days=5)).isoformat(), "entities": [
                       {"name": "Club de Montaña", "entity_type": "organization", "role": "organizer"}],
                   "source_name": "Agenda local", "source_url": "https://example.org/ruta"}
        activity_id, created = core.upsert_activity(payload)
        self.assertTrue(created)
        rows = core.get_activities()
        activity = next(x for x in rows if x["id"] == activity_id)
        self.assertEqual(set(activity["category_ids"]), {"deporte", "voluntariado"})
        self.assertEqual(activity["entities"][0]["name"], "Club de Montaña")
        self.assertEqual(activity["announced_at"], payload["announced_at"])
        self.assertEqual(activity["registration_opens_at"], payload["registration_opens_at"])
        self.assertEqual(activity["sources"][0]["source_name"], "Agenda local")
        _, created_again = core.upsert_activity({**payload, "verification": "unverified", "status": "scheduled"})
        self.assertFalse(created_again)
        activity = next(x for x in core.get_activities() if x["id"] == activity_id)
        self.assertEqual(activity["verification"], "official")

    def test_16_generic_api_and_instance_config(self):
        status, raw = self.req("/api/instance")
        self.assertEqual(status, 200)
        config = json.loads(raw)
        self.assertEqual(config["geographic_mode"], "local")
        self.assertIn("Ourense", config["municipalities"])
        self.assertEqual(self.req("/api/categories")[0], 200)
        starts = (date.today() + timedelta(days=70)).isoformat()
        data = {"title": "Taller de fotografía", "municipality": "Vigo", "starts_at": starts,
                "category_id": "talleres", "source_name": "Test", "source_url": "https://example.org/taller"}
        self.assertEqual(self.req("/api/activities", data)[0], 403)
        self.assertEqual(self.req("/api/activities", data, "t" * 32)[0], 201)
        self.assertEqual(self.req("/api/activities")[0], 200)
        outside = {**data, "title": "Taller fuera", "municipality": "A Coruña"}
        self.assertEqual(self.req("/api/activities", outside, "t" * 32)[0], 400)

    def test_17_generic_collector_mapping(self):
        item = {"title": "Taller de fotografía", "text": "Iniciación a la fotografía", "place": "Centro cultural, Vigo",
                "date": (date.today() + timedelta(days=80)).isoformat(), "url": "https://example.org/taller"}
        ev, why = collector.to_activity(item, {"model": "activity", "name": "Agenda", "category_ids": ["talleres"], "status": "announced"})
        self.assertIsNone(why)
        self.assertEqual(ev["municipality"], "Vigo")
        self.assertEqual(ev["category_ids"], ["talleres"])
        self.assertEqual(ev["verification"], "single_source")

    def test_18_activity_verification_cannot_be_downgraded(self):
        starts = (date.today() + timedelta(days=90)).isoformat()
        base = {"title": "Feria local", "municipality": "Santiago de Compostela", "starts_at": starts,
                "category_id": "fiestas-ferias", "verification": "official", "source_url": "https://official.example/feria"}
        aid, created = core.upsert_activity(base)
        self.assertTrue(created)
        core.upsert_activity({**base, "verification": "unverified", "source_name": "Agregador", "source_url": "https://aggregator.example/feria"})
        activity = next(x for x in core.get_activities() if x["id"] == aid)
        self.assertEqual(activity["verification"], "official")



    def test_19_cultura_403_is_reported_without_retry(self):
        import urllib.error
        error = urllib.error.HTTPError("https://www.cultura.gal/services/abertos", 403, "Forbidden", {}, None)
        with patch("urllib.request.urlopen", side_effect=error) as mocked:
            with self.assertRaisesRegex(RuntimeError, "HTTP 403.*No se reintenta"):
                collector.fetch_post_form("https://www.cultura.gal/services/abertos", {"concello": 502})
        self.assertEqual(mocked.call_count, 1)



    def test_20_v33_database_migrates_without_losing_legacy_event(self):
        import sqlite3
        with tempfile.TemporaryDirectory() as td:
            db_path = Path(td) / "legacy-v33.sqlite3"
            conn = sqlite3.connect(db_path)
            conn.execute('''CREATE TABLE events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, fingerprint TEXT NOT NULL UNIQUE,
                artist TEXT NOT NULL, city TEXT NOT NULL, venue TEXT NOT NULL DEFAULT '',
                date TEXT NOT NULL, style TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'Concierto',
                status TEXT NOT NULL DEFAULT 'announced', source TEXT NOT NULL DEFAULT '',
                source_url TEXT NOT NULL DEFAULT '', ticket_url TEXT NOT NULL DEFAULT '',
                announced_at TEXT NOT NULL DEFAULT '', presale_at TEXT NOT NULL DEFAULT '',
                style_source_url TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL, updated_at TEXT NOT NULL, notified_at TEXT)''')
            future = (date.today() + timedelta(days=100)).isoformat()
            conn.execute('''INSERT INTO events(fingerprint,artist,city,date,style,status,source,source_url,announced_at,presale_at,created_at,updated_at)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
                         ("legacy-fingerprint", "Hard GZ", "Vigo", future, "Rap", "confirmed",
                          "Agenda oficial", "https://example.org/hardgz", "2026-11-10", "2026-11-12",
                          "2026-11-15T10:00:00+00:00", "2026-11-15T10:00:00+00:00"))
            conn.execute("PRAGMA user_version=6")
            conn.commit(); conn.close()
            old_db = core.DB
            try:
                core.DB = db_path
                core.init_db()
                with core.connect() as db:
                    legacy = db.execute("SELECT COUNT(*) FROM events WHERE artist='Hard GZ'").fetchone()[0]
                    activity = db.execute("SELECT title,status,verification,announced_at,registration_opens_at FROM activities WHERE legacy_event_id=1").fetchone()
                self.assertEqual(legacy, 1)
                self.assertEqual(tuple(activity), ("Hard GZ", "scheduled", "official", "2026-11-10", "2026-11-12"))
            finally:
                core.DB = old_db



    def test_21_admin_panel_and_api_authentication(self):
        self.assertEqual(self.req("/admin.html")[0], 200)
        self.assertEqual(self.req("/api/admin/config")[0], 403)
        self.assertEqual(self.req("/api/admin/config", token="x" * 32)[0], 403)
        status, raw = self.req("/api/admin/config", token="t" * 32)
        self.assertEqual(status, 200)
        cfg = json.loads(raw)
        self.assertIn("instance", cfg)
        self.assertIn("categories", cfg)
        self.assertIn("sources", cfg)

    def test_22_admin_instance_and_source_validation(self):
        from unittest.mock import patch
        config_dir = Path(tempfile.mkdtemp())
        with patch.object(core, "CONFIG_DIR", config_dir):
            invalid = {"name": "Rúa test", "timezone": "Not/AZone", "geographic_mode": "local", "municipalities": ["Vigo"]}
            self.assertEqual(self.req("/api/admin/instance", invalid, "t" * 32, "PUT")[0], 400)
            valid = {"name": "Rúa de proba", "description": "Instancia de test", "timezone": "Europe/Madrid",
                     "geographic_mode": "local", "municipalities": ["Vigo"], "default_radius_km": 20,
                     "allow_public_registration": False, "federation_enabled": False}
            status, raw = self.req("/api/admin/instance", valid, "t" * 32, "PUT")
            self.assertEqual(status, 200, raw)
            self.assertEqual(core.get_instance_config()["name"], "Rúa de proba")
            safe_source = [{"name": "Fonte de proba", "type": "rss", "url": "https://example.org/feed.xml", "enabled": True, "status": "announced"}]
            self.assertEqual(self.req("/api/admin/sources", safe_source, "t" * 32, "PUT")[0], 200)
            unsafe_source = [{"name": "Fonte insegura", "type": "rss", "url": "http://example.org/feed.xml", "enabled": True}]
            self.assertEqual(self.req("/api/admin/sources", unsafe_source, "t" * 32, "PUT")[0], 400)

    def test_23_admin_category_validation_and_persistence(self):
        from unittest.mock import patch
        config_dir = Path(tempfile.mkdtemp())
        with patch.object(core, "CONFIG_DIR", config_dir):
            categories = server.admin_categories()
            categories.append({"id": "test-local", "name": "Probas locais", "parent_id": None, "enabled": True})
            status, raw = self.req("/api/admin/categories", categories, "t" * 32, "PUT")
            self.assertEqual(status, 200, raw)
            saved = json.loads((config_dir / "categories.json").read_text(encoding="utf-8"))
            self.assertIn("test-local", [x["id"] for x in saved])
            cyclic = [{"id": "cycle-a", "name": "A", "parent_id": "cycle-b", "enabled": True},
                      {"id": "cycle-b", "name": "B", "parent_id": "cycle-a", "enabled": True}]
            self.assertEqual(self.req("/api/admin/categories", cyclic, "t" * 32, "PUT")[0], 400)


if __name__ == "__main__":
    unittest.main()
