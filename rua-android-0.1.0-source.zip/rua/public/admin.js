const $ = id => document.getElementById(id);
let token = sessionStorage.getItem("rua-admin-token") || "";
const authHeaders = () => ({"Authorization": `Bearer ${token}`, "Accept":"application/json"});
async function api(path, options={}) {
  const response = await fetch(path, {...options, headers:{...authHeaders(), ...(options.body?{"Content-Type":"application/json"}:{}), ...(options.headers||{})}, cache:"no-store"});
  const payload = await response.json().catch(()=>({error:`Respuesta HTTP ${response.status}`}));
  if (!response.ok) throw new Error(payload.error || `Error HTTP ${response.status}`);
  return payload;
}
function message(id, text, error=false){const el=$(id);el.textContent=text;el.classList.toggle("error",error);}
async function connect(){
  token=$("token").value.trim();
  if(!token){message("authMessage","Introduce el token configurado en RUA_ADMIN_TOKEN.",true);return;}
  try{
    await api("/api/admin/check");
    sessionStorage.setItem("rua-admin-token",token);
    const cfg=await api("/api/admin/config");
    paint(cfg);$("authPanel").hidden=true;$("workspace").hidden=false;
    message("authMessage","");
  }catch(err){sessionStorage.removeItem("rua-admin-token");message("authMessage",err.message,true);}
}
function paint(cfg){
  const x=cfg.instance;
  $("name").value=x.name||"";$("description").value=x.description||"";$("timezone").value=x.timezone||"Europe/Madrid";
  $("geographic_mode").value=x.geographic_mode||"local";$("radius").value=x.default_radius_km??25;
  $("municipalities").value=(x.municipalities||[]).join("\n");$("registration").checked=!!x.allow_public_registration;
  $("federation").checked=!!x.federation_enabled;
  $("categories").value=JSON.stringify(cfg.categories,null,2);$("sources").value=JSON.stringify(cfg.sources,null,2);
}
async function save(path, body, messageId, success){
  try{const result=await api(path,{method:"PUT",body:JSON.stringify(body)});message(messageId,`${success} (${result.count??"OK"}).`);}
  catch(err){message(messageId,err.message,true);}
}
$("connect").addEventListener("click",connect);
$("token").value=token;
$("token").addEventListener("keydown",e=>{if(e.key==="Enter")connect();});
$("saveInstance").addEventListener("click",()=>save("/api/admin/instance",{
  name:$("name").value,description:$("description").value,timezone:$("timezone").value,
  geographic_mode:$("geographic_mode").value,default_radius_km:Number($("radius").value),
  municipalities:$("municipalities").value.split("\n").map(x=>x.trim()).filter(Boolean),
  allow_public_registration:$("registration").checked,federation_enabled:$("federation").checked
},"instanceMessage","Configuración guardada"));
$("saveCategories").addEventListener("click",()=>{try{save("/api/admin/categories",JSON.parse($("categories").value),"categoriesMessage","Categorías guardadas");}catch(e){message("categoriesMessage",`JSON no válido: ${e.message}`,true);}});
$("saveSources").addEventListener("click",()=>{try{save("/api/admin/sources",JSON.parse($("sources").value),"sourcesMessage","Fuentes guardadas");}catch(e){message("sourcesMessage",`JSON no válido: ${e.message}`,true);}});
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===btn));
  document.querySelectorAll(".tab-panel").forEach(x=>x.hidden=x.id!==`tab-${btn.dataset.tab}`);
}));
if(token) connect();
