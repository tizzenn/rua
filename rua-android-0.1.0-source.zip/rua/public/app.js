const $ = id => document.getElementById(id);
let events = [];
let apiOnline = false;
let sourceStatus = null;
let lastLoaded = null;

const fmt = date => {
  const d=new Date(date+"T12:00:00");
  return {day:d.toLocaleDateString("es-ES",{day:"2-digit"}),month:d.toLocaleDateString("es-ES",{month:"short"}).replace(".","").toUpperCase()};
};
const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

function render(){
  const city=$("cityFilter").value, style=$("styleFilter").value, type=$("typeFilter").value, q=$("searchInput").value.trim().toLowerCase();
  const filtered=events.filter(e=>(city==="Todas"||e.city===city)&&(style==="Todos"||e.style===style)&&(type==="Todos"||e.type===type)&&[e.artist,e.city,e.venue,e.style].join(" ").toLowerCase().includes(q));
  $("eventCount").textContent=`${filtered.length} ${filtered.length===1?"evento":"eventos"}`;
  const root=$("eventsList");
  paintSourceStatus();
  if(!filtered.length){
    root.innerHTML='<div class="empty"><strong>No hay eventos con esos filtros.</strong><p>Cuando incorporemos nuevos anuncios, aparecerán aquí automáticamente.</p></div>';
    return;
  }
  root.innerHTML=filtered.map(e=>{
    const d=fmt(e.date);
    const source=e.source_url
      ? `<a class="source" href="${escapeHTML(e.source_url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(e.source||"Ver fuente")} ↗</a>`
      : `<span class="source">${escapeHTML(e.source||"Fuente pendiente")}</span>`;
    const ticket=e.ticket_url
      ? `<a class="ticket-link" href="${escapeHTML(e.ticket_url)}" target="_blank" rel="noopener noreferrer">ENTRADAS ↗</a>` : "";
    const styleSource=e.style_source_url && e.style_source_url!==e.source_url
      ? `<a class="source" href="${escapeHTML(e.style_source_url)}" target="_blank" rel="noopener noreferrer">FUENTE DEL ESTILO ↗</a>` : "";
    const status=e.status==="confirmed"?"CONFIRMADO":e.status==="unverified"?"NO VERIFICADO":"ANUNCIADO";
    const dates=[e.announced_at?`Anuncio: ${escapeHTML(e.announced_at)}`:"Fecha de anuncio no consta",e.presale_at?`Preventa: ${escapeHTML(e.presale_at)}`:""].filter(Boolean).join(" · ");
    return `<article class="event-card"><div class="datebox"><strong>${d.day}</strong><span>${d.month}</span></div><div class="event-info"><div class="tags"><span class="tag">${escapeHTML(e.style||"Estilo no acreditado")}</span><span class="tag">${escapeHTML(e.type)}</span><span class="tag ${e.status==="confirmed"?"confirmed":""}">${status}</span></div><h3>${escapeHTML(e.artist)}</h3><div class="meta">${escapeHTML(e.city)} · ${escapeHTML(e.venue||"Sala por anunciar")}</div><div class="event-dates">${dates}</div>${e.notes?`<p class="event-notes">${escapeHTML(e.notes)}</p>`:""}${source}${styleSource}${ticket}</div></article>`;
  }).join("");
}
function paintSourceStatus(){
  const el=$("sourceStatus");
  if(!el)return;
  if(!apiOnline){el.textContent="No se puede consultar el estado de las fuentes: servidor desconectado.";el.classList.add("warning");return;}
  if(!sourceStatus){el.textContent="No se ha podido consultar el estado de las fuentes en esta carga.";el.classList.add("warning");return;}
  const enabled=sourceStatus.sources.filter(s=>s.enabled), ok=enabled.filter(s=>s.status==="ok"), errors=enabled.filter(s=>s.status==="error"), pending=enabled.filter(s=>s.status==="pending");
  const latest=ok.map(s=>s.last_checked).filter(Boolean).sort().at(-1);
  const stamp=latest?new Date(latest).toLocaleString("es-ES",{dateStyle:"short",timeStyle:"short"}):"sin ejecuciones registradas";
  if(errors.length||pending.length){
    const detail=[...errors.map(s=>`${s.name}: ${s.error||"error de consulta"}`),...pending.map(s=>`${s.name}: aún sin ejecutar`)].join(" · ");
    el.textContent=`Fuentes: ${ok.length}/${enabled.length} correctas · Última consulta: ${stamp}. ${detail}`;
    el.classList.add("warning");
  }else{
    el.textContent=`Fuentes: ${ok.length}/${enabled.length} correctas · Última consulta: ${stamp}`;
    el.classList.remove("warning");
  }
}
async function loadEvents(){
  try{
    const response=await fetch("./api/events",{headers:{"Accept":"application/json"},cache:"no-store"});
    if(!response.ok)throw new Error("API no disponible");
    const data=await response.json();
    events=data.events||[];
    try{
      const statusResponse=await fetch("./api/status",{headers:{"Accept":"application/json"},cache:"no-store"});
      sourceStatus=statusResponse.ok?await statusResponse.json():null;
    }catch(_){sourceStatus=null;}
    apiOnline=true;lastLoaded=new Date();
    $("apiStatus").textContent="DATOS CONECTADOS";
    $("apiStatus").classList.add("online");
  }catch(err){
    apiOnline=false;
    $("apiStatus").textContent="SERVIDOR DESCONECTADO";
    $("apiStatus").classList.remove("online");
  }
  render();
}
["cityFilter","styleFilter","typeFilter","searchInput"].forEach(id=>$(id).addEventListener("input",render));
loadEvents();
// Actualiza al volver a la app y periódicamente, sin gastar peticiones en segundo plano.
setInterval(()=>{if(document.visibilityState==="visible")loadEvents();},5*60*1000);
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible")loadEvents();});
let deferredPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("installBtn").hidden=false;});
$("installBtn").addEventListener("click",async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("installBtn").hidden=true;});
if("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost")) navigator.serviceWorker.register("./sw.js").catch(()=>{});


// ---- Avisos push ----
const urlB64 = b => { const p = "=".repeat((4 - b.length % 4) % 4), s = (b + p).replace(/-/g, "+").replace(/_/g, "/"); return Uint8Array.from(atob(s), c => c.charCodeAt(0)); };
async function initPush() {
  const btn = $("pushBtn");
  if (!("serviceWorker" in navigator && "PushManager" in window && "Notification" in window)) return;
  let reg, key;
  try {
    reg = await navigator.serviceWorker.ready;
    const r = await fetch("/api/push/key"); if (!r.ok) return;   // servidor sin push: botón oculto
    key = (await r.json()).publicKey;
  } catch (_) { return; }
  btn.hidden = false;
  const paint = on => { btn.textContent = on ? "AVISOS ACTIVOS" : "ACTIVAR AVISOS"; btn.classList.toggle("on", on); };
  paint(!!(await reg.pushManager.getSubscription()));
  btn.addEventListener("click", async () => {
    btn.disabled = true;
    try {
      const cur = await reg.pushManager.getSubscription();
      if (cur) {
        await fetch("/api/push/unsubscribe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ endpoint: cur.endpoint }) });
        await cur.unsubscribe(); paint(false);
      } else {
        if (await Notification.requestPermission() !== "granted") { btn.textContent = "PERMISO DENEGADO"; return; }
        const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlB64(key) });
        const res = await fetch("/api/push/subscribe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(sub) });
        if (!res.ok) { await sub.unsubscribe(); throw new Error("rechazada"); }
        paint(true);
      }
    } catch (_) { btn.textContent = "ERROR · REINTENTAR"; }
    finally { btn.disabled = false; }
  });
}
initPush();
