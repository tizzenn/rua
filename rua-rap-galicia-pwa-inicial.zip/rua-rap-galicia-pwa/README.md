# Rúa — Rap en Galicia (PWA inicial)

Prototipo instalable de agenda para rap, trap, drill, underground y rap gallego en Ourense, Vigo y Santiago de Compostela.

## Qué incluye esta primera entrega
- Interfaz adaptable a móvil y escritorio.
- Filtros por ciudad, estilo y tipo de evento.
- Búsqueda por artista, sala o ciudad.
- Manifiesto PWA e icono.
- Service worker con caché básica para abrir la interfaz sin conexión.
- Preparación del botón de instalación cuando el navegador ofrece esa posibilidad.

**Importante:** los tres eventos que aparecen son ficticios y llevan la etiqueta DEMO. No son conciertos reales. Todavía no hay fuentes conectadas, base de datos, RSS ni notificaciones push.

## Probar en Arch Linux
Desde el directorio descomprimido:

```bash
python -m http.server 8000
```

Abre `http://localhost:8000` en el ordenador.

Para probar en un móvil de la misma red local puedes usar la IP local del ordenador, pero el service worker y la instalación PWA requieren HTTPS o `localhost`. Para instalarla en Android habrá que publicarla en un dominio con HTTPS y abrirla con Chrome/Chromium.

## Próximas fases
1. Backend y base de datos de eventos.
2. Conectores de fuentes y normalización de datos.
3. Detección de duplicados y novedades.
4. RSS.
5. Notificaciones push y despliegue HTTPS.
