const demoEvents = [
  {artist:"Artista de ejemplo",city:"Vigo",venue:"Sala por confirmar",date:"2027-02-12",style:"Rap",type:"Concierto",source:"Evento ficticio de demostración"},
  {artist:"Proyecto underground",city:"Ourense",venue:"Recinto por confirmar",date:"2027-03-06",style:"Underground",type:"Sesión / fiesta",source:"Evento ficticio de demostración"},
  {artist:"Rap en galego",city:"Santiago de Compostela",venue:"Sala por confirmar",date:"2027-04-18",style:"Rap gallego",type:"Festival",source:"Evento ficticio de demostración"}
];
const $ = id => document.getElementById(id);
const fmt = date => {const d=new Date(date+"T12:00:00");return {day:d.toLocaleDateString("es-ES",{day:"2-digit"}),month:d.toLocaleDateString("es-ES",{month:"short"}).replace(".","").toUpperCase()};};
function render(){
  const city=$("cityFilter").value, style=$("styleFilter").value, type=$("typeFilter").value, q=$("searchInput").value.trim().toLowerCase();
  const filtered=demoEvents.filter(e=>(city==="Todas"||e.city===city)&&(style==="Todos"||e.style===style)&&(type==="Todos"||e.type===type)&&[e.artist,e.city,e.venue,e.style].join(" ").toLowerCase().includes(q));
  $("eventCount").textContent=`${filtered.length} ${filtered.length===1?"evento":"eventos"}`;
  const root=$("eventsList");
  if(!filtered.length){root.innerHTML='<div class="empty"><strong>No hay eventos con esos filtros.</strong><p>Cuando conectemos las fuentes de conciertos, aquí aparecerán los anuncios que encajen con tu búsqueda.</p></div>';return;}
  root.innerHTML=filtered.map(e=>{const d=fmt(e.date);return `<article class="event-card"><div class="datebox"><strong>${d.day}</strong><span>${d.month}</span></div><div class="event-info"><div class="tags"><span class="tag">${e.style}</span><span class="tag">${e.type}</span><span class="tag demo">DEMO</span></div><h3>${e.artist}</h3><div class="meta">${e.city} · ${e.venue}</div><span class="source">${e.source}</span></div></article>`;}).join("");
}
["cityFilter","styleFilter","typeFilter","searchInput"].forEach(id=>$(id).addEventListener("input",render));
render();
let deferredPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("installBtn").hidden=false;});
$("installBtn").addEventListener("click",async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("installBtn").hidden=true;});
if("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
