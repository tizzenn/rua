"""Pruebas locales: python -m unittest discover -s tests"""
import os, sys, json, tempfile, threading, unittest, urllib.request, urllib.error
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import date, timedelta
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ["RUA_DB"] = str(Path(tempfile.mkdtemp()) / "t.sqlite3")
os.environ["RUA_ADMIN_TOKEN"] = "t" * 32
import core, collector, push, server  # noqa

F = (date.today() + timedelta(days=30)).strftime("%Y%m%d")
ICS = f"""BEGIN:VCALENDAR\r
BEGIN:VEVENT\r
SUMMARY:Noche de rap gallego\r
DTSTART;VALUE=DATE:{F}\r
LOCATION:Sala Capitol\\, Santiago de Compostela\r
URL:https://example.com/e1\r
END:VEVENT\r
BEGIN:VEVENT\r
SUMMARY:Concierto de jazz\r
DTSTART;VALUE=DATE:{F}\r
LOCATION:Vigo\r
END:VEVENT\r
BEGIN:VEVENT\r
SUMMARY:Trap night\r
DTSTART;VALUE=DATE:{F}\r
LOCATION:A Coruña\r
END:VEVENT\r
BEGIN:VEVENT\r
SUMMARY:DJ session drill\r
DTSTART;VALUE=DATE:20200101\r
LOCATION:Vigo\r
END:VEVENT\r
END:VCALENDAR\r
""".encode()


class Feed(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200); self.end_headers(); self.wfile.write(ICS)
    def log_message(self, *a): pass


class T(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        core.init_db()
        cls.feed = HTTPServer(("127.0.0.1", 0), Feed)
        threading.Thread(target=cls.feed.serve_forever, daemon=True).start()
        cls.api = server.ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        threading.Thread(target=cls.api.serve_forever, daemon=True).start()
        cls.base = f"http://127.0.0.1:{cls.api.server_port}"

    def req(self, path, data=None, token=None):
        r = urllib.request.Request(self.base + path, data=json.dumps(data).encode() if data is not None else None,
                                   headers={"Content-Type": "application/json", **({"Authorization": f"Bearer {token}"} if token else {})})
        try:
            with urllib.request.urlopen(r) as x: return x.status, x.read()
        except urllib.error.HTTPError as e: return e.code, e.read()

    def test_1_no_leaks(self):
        for p in ("/rua.sqlite3", "/server.py", "/core.py", "/vapid_private.pem", "/../server.py"):
            self.assertNotEqual(self.req(p)[0], 200, p)
        self.assertEqual(self.req("/index.html")[0], 200)

    def test_2_collector(self):
        src = {"name": "Test", "type": "ics", "url": f"http://127.0.0.1:{self.feed.server_port}/x.ics", "status": "announced"}
        evs = [to for to in (collector.to_event(i, src) for i in collector.collect(src))]
        ok = [e for e, _ in evs if e]
        self.assertEqual(len(ok), 1)
        self.assertEqual((ok[0]["city"], ok[0]["style"]), ("Santiago de Compostela", "Rap gallego"))
        self.assertEqual([w for e, w in evs if not e], ["estilo no coincide", "ciudad fuera de ámbito", "pasado"])

    def test_3_dedupe_and_rss(self):
        base = {"artist": "Artista X", "city": "Vigo", "date": F[:4] + "-" + F[4:6] + "-" + F[6:], "style": "Rap"}
        a, c1 = core.upsert_event({**base, "venue": ""}); b, c2 = core.upsert_event({**base, "venue": "Sala Rouge", "status": "confirmed"})
        self.assertEqual((a, c1, c2), (b, True, False))
        with core.connect() as db:
            row = db.execute("SELECT venue,status FROM events WHERE id=?", (a,)).fetchone()
        self.assertEqual((row["venue"], row["status"]), ("Sala Rouge", "confirmed"))
        import xml.etree.ElementTree as ET
        root = ET.fromstring(core.rss_feed())
        from email.utils import parsedate_to_datetime
        self.assertIsNotNone(parsedate_to_datetime(root.find("channel/item/pubDate").text).tzinfo)

    def test_4_validation_and_auth(self):
        bad = {"artist": "X", "city": "A Coruña", "date": "2030-01-01", "style": "Rap"}
        self.assertEqual(self.req("/api/events", bad, "t" * 32)[0], 400)
        self.assertEqual(self.req("/api/events", bad)[0], 403)
        self.assertEqual(self.req("/api/events", bad, "x" * 32)[0], 403)

    def test_5_push_endpoints(self):
        self.assertEqual(self.req("/api/push/key")[0], 503)  # sin claves
        sub = {"endpoint": "https://push.example/abc", "keys": {"p256dh": "k", "auth": "a"}}
        self.assertEqual(self.req("/api/push/subscribe", sub)[0], 201)
        self.assertEqual(self.req("/api/push/subscribe", {**sub, "endpoint": "http://x"})[0], 400)
        self.assertEqual(self.req("/api/push/unsubscribe", sub)[0], 200)

    def test_6_notify_marks_once(self):
        push.notify_new(mark_only=True)
        with core.connect() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM events WHERE notified_at IS NULL").fetchone()[0], 0)

if __name__ == "__main__":
    unittest.main()
