#!/usr/bin/env python3
"""Rúa: servidor HTTP (PWA + API + RSS + suscripciones push). Solo sirve ./public."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse
from pathlib import Path
import json, os, sys, hmac
import core, push

PUBLIC = core.ROOT / "public"
HOST = os.environ.get("RUA_HOST", "127.0.0.1")
PORT = int(os.environ.get("RUA_PORT", "8000"))
ADMIN_TOKEN = os.environ.get("RUA_ADMIN_TOKEN", "")
MAX_SUBS = int(os.environ.get("RUA_MAX_SUBSCRIPTIONS", "500"))


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(PUBLIC), **kw)

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        super().end_headers()

    def send_json(self, code, payload):
        body = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self, limit=1_000_000):
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > limit:
            raise ValueError("Tamaño de petición no válido.")
        return json.loads(self.rfile.read(length))

    def is_admin(self):
        token = self.headers.get("Authorization", "").removeprefix("Bearer ").strip()
        return bool(ADMIN_TOKEN) and hmac.compare_digest(token.encode(), ADMIN_TOKEN.encode())

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/health":
            return self.send_json(200, {"ok": True, "service": "rua", "push": push.available()})
        if path == "/api/events":
            events = core.get_events()
            for e in events:
                e.pop("fingerprint", None); e.pop("notified_at", None)
            return self.send_json(200, {"events": events, "count": len(events)})
        if path == "/api/push/key":
            key = push.public_key()
            if not key:
                return self.send_json(503, {"error": "Push no configurado en el servidor."})
            return self.send_json(200, {"publicKey": key})
        if path == "/feed.xml":
            body = core.rss_feed().encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/rss+xml; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(body)
            return
        if path.startswith("/api/"):
            return self.send_json(404, {"error": "Ruta no encontrada."})
        return super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            if path == "/api/events":
                if not self.is_admin():
                    return self.send_json(403, {"error": "Define RUA_ADMIN_TOKEN y envía Authorization: Bearer <token>."})
                data = self.read_json()
                batch = data if isinstance(data, list) else [data]
                if len(batch) > 200:
                    raise ValueError("Máximo 200 eventos por petición.")
                results = [core.upsert_event(i) for i in batch]
                return self.send_json(201, {"inserted": sum(1 for _, c in results if c),
                                            "updated": sum(1 for _, c in results if not c)})
            if path == "/api/push/subscribe":
                return self.send_json(201, push.add_subscription(self.read_json(10_000), MAX_SUBS))
            if path == "/api/push/unsubscribe":
                return self.send_json(200, push.remove_subscription(self.read_json(10_000)))
            return self.send_json(404, {"error": "Ruta no encontrada."})
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            return self.send_json(400, {"error": str(exc)})

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))


def main():
    core.init_db()
    if len(sys.argv) > 1 and sys.argv[1] == "import":
        if len(sys.argv) < 3:
            print("Uso: python server.py import eventos.json"); raise SystemExit(2)
        data = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
        for item in (data if isinstance(data, list) else [data]):
            eid, created = core.upsert_event(item)
            print("Añadido" if created else "Actualizado", eid, item.get("artist"))
        return
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"Rúa en http://{HOST}:{PORT}  ·  RSS: {core.BASE_URL}/feed.xml")
    if not ADMIN_TOKEN:
        print("Aviso: RUA_ADMIN_TOKEN vacío; POST /api/events deshabilitado.")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nCerrando servidor…")
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
