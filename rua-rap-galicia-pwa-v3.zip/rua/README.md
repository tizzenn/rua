# Rúa — Rap en Galicia (v3)

PWA + API + RSS + recolector + avisos push. Ámbito: Ourense, Vigo y Santiago de Compostela.
Estilos: Rap, Trap, Drill, Underground, Rap gallego.

## Arranque local (Arch Linux)
```bash
export RUA_ADMIN_TOKEN="$(openssl rand -hex 24)"
python server.py            # http://127.0.0.1:8000  ·  RSS en /feed.xml
python -m unittest discover -s tests
```
Sin dependencias para web, API, RSS y recolector. Solo el envío de push necesita `pywebpush`.

## Qué cambia respecto a v2
- Solo se sirve `public/`: ya no se pueden descargar `rua.sqlite3` ni el código.
- Service worker: red primero para `/api/events`; ya no muestra datos viejos.
- RSS válido (fechas RFC 822, `atom:link`, enlaces con `RUA_BASE_URL`), ordenado por fecha de detección.
- Token comparado en tiempo constante; sin token configurado, el alta por API queda desactivada.
- Huella de duplicados = artista + ciudad + fecha (la sala ya no genera duplicados). La BD v2 se migra sola.
- Una actualización con campos vacíos no borra los datos existentes.

## Recolector (fase 2)
Edita `sources.json`. Tipos: `ics`, `rss`, `json` (con `items_path` y `map`).
```bash
python collector.py --dry-run     # muestra qué importaría, sin guardar
python collector.py               # importa y avisa de novedades
```
Reglas: se importa un evento solo si encaja ciudad **y** estilo. El estilo se infiere por palabras clave
(`rap`, `trap`, `drill`, `underground`, `rap/trap galego`), por lo que las fuentes quedan como
`unverified` salvo que marques `"status": "announced"` en una fuente oficial. Se descartan
eventos pasados, sin fecha o fuera de ámbito.

**La URL de la agenda de Cultura de Galicia no está verificada:** la fuente viene desactivada con un
marcador. Copia la URL ICS/RSS/JSON desde su página de datos abiertos, pégala en `sources.json` y
pasa `enabled` a `true`. Prueba siempre con `--dry-run` primero. Si el formato difiere (p. ej. JSON),
ajusta `map`/`items_path`.
Las RSS suelen no traer fecha del evento; solo se importan si la fecha aparece en el título o el texto.

Limitación: las agendas generalistas rara vez etiquetan el estilo; un concierto de rap sin esa palabra
en título/descripción no se detectará. Bandsintown, Songkick y webs de salas no tienen conector
(sin API pública estable o con restricciones de uso); se añaden como nuevos lectores si los verificas.

## Notificaciones push (fase 3)
```bash
pip install -r requirements.txt
python push.py genkeys                 # crea vapid_private.pem (600); haz copia, no la pierdas
export RUA_VAPID_SUBJECT="mailto:tu@correo.es"
```
- Push requiere **HTTPS** (o `localhost`). Con Caddy ver `deploy/Caddyfile`.
- Abre la web, pulsa **ACTIVAR AVISOS** y acepta el permiso en Android (Chrome).
- La primera vez, para no avisar de lo ya existente: `python push.py notify --mark-only`.
- `collector.py` llama a `push.notify_new()` tras cada ejecución. Sin novedades, no envía nada.
  Más de 3 novedades se resumen en un solo aviso. Suscripciones caducadas (404/410) se borran solas.
- Si regeneras las claves, todas las suscripciones dejan de valer.

Pendiente de prueba real: el envío extremo a extremo a un móvil (necesita HTTPS público).
Está verificado: generación de claves, endpoints de suscripción, marcado de notificados y la lógica.

## Despliegue (servidor propio o VPS)
1. Copia el proyecto a `/opt/rua`, crea `python -m venv .venv && .venv/bin/pip install -r requirements.txt`.
2. `/etc/rua.env` (permisos 600): `RUA_ADMIN_TOKEN`, `RUA_BASE_URL=https://rua.tudominio.es`, `RUA_VAPID_SUBJECT`.
3. Instala `deploy/*.service` y `deploy/rua-collector.timer` en `/etc/systemd/system/`;
   `systemctl enable --now rua.service rua-collector.timer`. (La unidad web usa `python3` del sistema; ajústala al venv si usas push desde el servidor.)
4. Caddy delante para HTTPS.

## Seguridad
- `/api/push/subscribe` es público (limitado por `RUA_MAX_SUBSCRIPTIONS`, 500 por defecto).
- No subas `vapid_private.pem` ni `rua.sqlite3`.
- El servidor integrado es para uso personal, detrás de un proxy inverso.

## Importación manual
```bash
python server.py import eventos-ejemplo.json
```
