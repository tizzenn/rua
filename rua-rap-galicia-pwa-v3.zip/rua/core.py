"""Rúa core: SQLite, validación, deduplicación y RSS. Solo biblioteca estándar."""
from pathlib import Path
from datetime import date, datetime, timezone
from email.utils import format_datetime
import sqlite3, os, hashlib, html, re, unicodedata

ROOT = Path(__file__).resolve().parent
DB = Path(os.environ.get("RUA_DB", ROOT / "rua.sqlite3"))
BASE_URL = os.environ.get("RUA_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
CITIES = {"Ourense", "Vigo", "Santiago de Compostela"}
STYLES = {"Rap", "Trap", "Drill", "Underground", "Rap gallego"}
TYPES = {"Concierto", "Sesión / fiesta", "Festival"}
STATUSES = {"confirmed", "announced", "unverified"}
FIELDS = ("artist", "city", "venue", "date", "style", "type", "status", "source",
          "source_url", "ticket_url", "announced_at", "notes")
SCHEMA_VERSION = 3


def connect():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def norm(text):
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", text.strip().lower())


def fingerprint(event):
    # Sin sala: el mismo concierto con la sala escrita distinto no se duplica.
    raw = "|".join(norm(event[k]) for k in ("artist", "city", "date"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def init_db():
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS events (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          fingerprint TEXT NOT NULL UNIQUE,
          artist TEXT NOT NULL, city TEXT NOT NULL,
          venue TEXT NOT NULL DEFAULT '', date TEXT NOT NULL,
          style TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'Concierto',
          status TEXT NOT NULL DEFAULT 'announced',
          source TEXT NOT NULL DEFAULT '', source_url TEXT NOT NULL DEFAULT '',
          ticket_url TEXT NOT NULL DEFAULT '', announced_at TEXT NOT NULL DEFAULT '',
          notes TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""")
        cols = {r["name"] for r in db.execute("PRAGMA table_info(events)")}
        if "notified_at" not in cols:
            db.execute("ALTER TABLE events ADD COLUMN notified_at TEXT")
        db.execute("CREATE INDEX IF NOT EXISTS idx_events_date ON events(date)")
        db.execute("""CREATE TABLE IF NOT EXISTS subscriptions (
          endpoint TEXT PRIMARY KEY, p256dh TEXT NOT NULL, auth TEXT NOT NULL,
          created_at TEXT NOT NULL)""")
        if db.execute("PRAGMA user_version").fetchone()[0] < SCHEMA_VERSION:
            # Migración de v2: huella nueva (sin sala). Si dos filas chocan, se conserva la más antigua.
            for r in db.execute("SELECT id, artist, city, date FROM events ORDER BY id").fetchall():
                fp = fingerprint(dict(r))
                try:
                    db.execute("UPDATE events SET fingerprint=? WHERE id=?", (fp, r["id"]))
                except sqlite3.IntegrityError:
                    db.execute("DELETE FROM events WHERE id=?", (r["id"],))
            db.execute(f"PRAGMA user_version={SCHEMA_VERSION}")


def validate_event(data):
    if not isinstance(data, dict):
        raise ValueError("El evento debe ser un objeto JSON.")
    for key in ("artist", "city", "date", "style"):
        if not isinstance(data.get(key), str) or not data[key].strip():
            raise ValueError(f"Falta el campo obligatorio: {key}")
    ev = {k: str(data.get(k) or "").strip() for k in FIELDS}
    if ev["city"] not in CITIES:
        raise ValueError("Ciudad no permitida. Solo Ourense, Vigo o Santiago de Compostela.")
    if ev["style"] not in STYLES:
        raise ValueError("Estilo no permitido.")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", ev["date"]):
        raise ValueError("La fecha debe tener formato YYYY-MM-DD.")
    date.fromisoformat(ev["date"])
    ev["type"] = ev["type"] or "Concierto"
    if ev["type"] not in TYPES:
        raise ValueError("Tipo de evento no permitido.")
    ev["status"] = ev["status"] or "announced"
    if ev["status"] not in STATUSES:
        raise ValueError("Estado no válido.")
    for key in ("source_url", "ticket_url"):
        if ev[key] and not ev[key].startswith(("https://", "http://")):
            raise ValueError(f"{key} debe ser una URL http(s).")
    return ev


def upsert_event(data):
    """Devuelve (id, creado). En actualizaciones, un valor vacío no borra el existente."""
    ev = validate_event(data)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    fp = fingerprint(ev)
    with connect() as db:
        old = db.execute("SELECT * FROM events WHERE fingerprint=?", (fp,)).fetchone()
        if old:
            merged = {k: (ev[k] or old[k]) for k in FIELDS}
            sets = ",".join(f"{k}=?" for k in FIELDS)
            db.execute(f"UPDATE events SET {sets},updated_at=? WHERE id=?",
                       (*[merged[k] for k in FIELDS], now, old["id"]))
            return old["id"], False
        cols = ",".join(FIELDS)
        cur = db.execute(
            f"INSERT INTO events (fingerprint,{cols},created_at,updated_at) VALUES (?,{','.join('?'*len(FIELDS))},?,?)",
            (fp, *[ev[k] for k in FIELDS], now, now))
        return cur.lastrowid, True


def get_events():
    with connect() as db:
        rows = db.execute("SELECT * FROM events WHERE date >= ? ORDER BY date, artist",
                          (date.today().isoformat(),)).fetchall()
        return [dict(r) for r in rows]


def _rfc822(iso):
    try:
        d = datetime.fromisoformat(iso)
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
    except ValueError:
        d = datetime.now(timezone.utc)
    return format_datetime(d)


def rss_feed():
    """Feed ordenado por fecha de detección (lo más nuevo primero)."""
    with connect() as db:
        rows = [dict(r) for r in db.execute(
            "SELECT * FROM events WHERE date >= ? ORDER BY created_at DESC, id DESC LIMIT 100",
            (date.today().isoformat(),))]
    labels = {"confirmed": "Confirmado", "announced": "Anunciado", "unverified": "Sin verificar"}
    items = []
    for e in rows:
        title = f'{e["artist"]} — {e["city"]} ({e["date"]})'
        desc = (f'{e["style"]} · {e["type"]} · {e["venue"] or "sala por anunciar"} · '
                f'{labels[e["status"]]}. Fuente: {e["source"] or "sin indicar"}.')
        link = e["source_url"] or e["ticket_url"] or BASE_URL + "/"
        items.append(
            f"<item><title>{html.escape(title)}</title>"
            f"<description>{html.escape(desc)}</description>"
            f"<link>{html.escape(link)}</link>"
            f'<guid isPermaLink="false">urn:rua:event:{e["fingerprint"]}</guid>'
            f"<pubDate>{_rfc822(e['created_at'])}</pubDate></item>")
    return ('<?xml version="1.0" encoding="UTF-8"?>'
            '<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom"><channel>'
            "<title>Rúa — Rap en Galicia</title>"
            f"<link>{html.escape(BASE_URL)}/</link>"
            f'<atom:link href="{html.escape(BASE_URL)}/feed.xml" rel="self" type="application/rss+xml"/>'
            "<description>Rap, trap, drill y underground en Ourense, Vigo y Santiago de Compostela.</description>"
            "<language>es</language>"
            f"<lastBuildDate>{format_datetime(datetime.now(timezone.utc))}</lastBuildDate>"
            f"{''.join(items)}</channel></rss>")
