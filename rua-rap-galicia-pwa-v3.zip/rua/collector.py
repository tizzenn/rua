#!/usr/bin/env python3
"""Recolector de eventos para Rúa (ICS, RSS y JSON genérico). Solo biblioteca estándar.

Uso:  python collector.py [--dry-run] [--no-notify]
Fuentes en sources.json. Solo se importan eventos que casen con ciudad Y estilo.
"""
import json, re, sys, urllib.request, xml.etree.ElementTree as ET
from datetime import date, datetime
from html import unescape
import core

UA = "Rua-collector/3.0 (+agenda personal; contacto en RUA_VAPID_SUBJECT)"
MAX_BYTES = 8_000_000

CITY_PATTERNS = {
    "Ourense": r"\bourense\b|\borense\b",
    "Vigo": r"\bvigo\b",
    "Santiago de Compostela": r"\bsantiago de compostela\b|\bcompostela\b|\bsantiago\b",
}
# Orden de prioridad: el primero que case gana.
STYLE_PATTERNS = [
    ("Rap gallego", r"\b(rap|trap|hip ?hop)\s+(galego|gallego)\b|\b(galego|gallego)\s+(rap|trap)\b"),
    ("Drill", r"\bdrill\b"),
    ("Trap", r"\btrap\b"),
    ("Rap", r"\brap\b|\brapero\b|\brapera\b|\bhip ?hop\b"),
    ("Underground", r"\bunderground\b"),
]
SESSION_RE = r"\b(dj|sesion|sesiones|fiesta|party|club night|noite)\b"
FESTIVAL_RE = r"\bfestival\b|\bfest\b"


def fetch(url):
    if not url.startswith(("https://", "http://")):
        raise ValueError("URL no permitida")
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=25) as r:
        data = r.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise ValueError("Respuesta demasiado grande")
    return data


def strip_tags(s):
    return re.sub(r"\s+", " ", unescape(re.sub(r"<[^>]+>", " ", s or ""))).strip()


def classify(text, forced_city=None):
    t = core.norm(text)
    city = forced_city if forced_city in core.CITIES else next(
        (c for c, p in CITY_PATTERNS.items() if re.search(p, t)), None)
    style = next((s for s, p in STYLE_PATTERNS if re.search(p, t)), None)
    kind = "Festival" if re.search(FESTIVAL_RE, t) else "Sesión / fiesta" if re.search(SESSION_RE, t) else "Concierto"
    return city, style, kind


def parse_date(s):
    s = (s or "").strip()
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", s) or re.search(r"(\d{4})(\d{2})(\d{2})", s)
    if m:
        y, mo, d = m.groups()
    else:
        m = re.search(r"(\d{1,2})[/.](\d{1,2})[/.](\d{4})", s)
        if not m:
            return None
        d, mo, y = m.groups()
    try:
        return date(int(y), int(mo), int(d)).isoformat()
    except ValueError:
        return None


def ics_unescape(v):
    return v.replace("\\n", " ").replace("\\N", " ").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")


def read_ics(raw):
    text = raw.decode("utf-8", "replace").replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"\n[ \t]", "", text)  # desplegar líneas
    for block in re.findall(r"BEGIN:VEVENT\n(.*?)\nEND:VEVENT", text, re.S):
        f = {}
        for line in block.split("\n"):
            if ":" in line:
                k, v = line.split(":", 1)
                f.setdefault(k.split(";")[0].upper(), ics_unescape(v))
        yield {"title": f.get("SUMMARY", ""), "text": f.get("DESCRIPTION", ""),
               "place": f.get("LOCATION", ""), "date": parse_date(f.get("DTSTART", "")),
               "url": f.get("URL", "")}


def read_rss(raw):
    root = ET.fromstring(raw)
    for it in root.iter("item"):
        g = lambda tag: (it.findtext(tag) or "")
        body = strip_tags(g("description"))
        yield {"title": strip_tags(g("title")), "text": body, "place": "",
               "date": parse_date(g("title") + " " + body), "url": g("link").strip()}


def dig(obj, path):
    for part in filter(None, (path or "").split(".")):
        obj = obj[int(part)] if isinstance(obj, list) else (obj or {}).get(part)
    return obj


def read_json(raw, src):
    m = src.get("map", {})
    items = dig(json.loads(raw), src.get("items_path", "")) or []
    for it in items:
        yield {"title": str(dig(it, m.get("title", "title")) or ""),
               "text": str(dig(it, m.get("text", "description")) or ""),
               "place": str(dig(it, m.get("place", "location")) or ""),
               "date": parse_date(str(dig(it, m.get("date", "date")) or "")),
               "url": str(dig(it, m.get("url", "url")) or "")}


def collect(src):
    raw = fetch(src["url"])
    kind = src["type"]
    if kind == "ics": return read_ics(raw)
    if kind == "rss": return read_rss(raw)
    if kind == "json": return read_json(raw, src)
    raise ValueError(f"Tipo de fuente desconocido: {kind}")


def to_event(item, src):
    if not item["title"] or not item["date"]:
        return None, "sin título o fecha"
    if item["date"] < date.today().isoformat():
        return None, "pasado"
    blob = " ".join((item["title"], item["text"], item["place"]))
    city, style, kind = classify(blob, src.get("city"))
    if not city: return None, "ciudad fuera de ámbito"
    if not style: return None, "estilo no coincide"
    return {"artist": item["title"][:160], "city": city, "venue": item["place"][:160],
            "date": item["date"], "style": style, "type": kind,
            "status": src.get("status", "unverified"), "source": src["name"],
            "source_url": item["url"] if item["url"].startswith(("http://", "https://")) else src.get("page", ""),
            "announced_at": date.today().isoformat(),
            "notes": "Estilo inferido por palabras clave; revisar en la fuente."}, None


def run(dry=False):
    core.init_db()
    sources = json.loads((core.ROOT / "sources.json").read_text(encoding="utf-8"))
    total_new = 0
    for src in sources:
        if not src.get("enabled", True) or "PON-AQUI" in src.get("url", "PON-AQUI"):
            print(f"[{src.get('name')}] omitida (desactivada o sin URL)"); continue
        try:
            items = list(collect(src))
        except Exception as exc:  # una fuente caída no detiene las demás
            print(f"[{src['name']}] ERROR: {exc}"); continue
        new = upd = skip = 0
        for item in items:
            ev, why = to_event(item, src)
            if not ev: skip += 1; continue
            if dry:
                print("  ·", ev["date"], ev["city"], ev["style"], "|", ev["artist"]); continue
            try:
                _, created = core.upsert_event(ev)
            except ValueError as exc:
                skip += 1; continue
            new += created; upd += (not created)
        total_new += new
        print(f"[{src['name']}] {len(items)} leídos · {new} nuevos · {upd} ya conocidos · {skip} descartados")
    return total_new


if __name__ == "__main__":
    n = run(dry="--dry-run" in sys.argv)
    if "--dry-run" not in sys.argv and "--no-notify" not in sys.argv:
        import push
        push.notify_new()
