# Rúa — Rap en Galicia (PWA + backend inicial)

## Requisitos
- Python 3.9 o posterior
- No necesita instalar paquetes Python externos

## Arrancar en Arch Linux
Desde esta carpeta:

```bash
python server.py
```

Abre `http://127.0.0.1:8000`. El backend crea automáticamente `rua.sqlite3`.

Para escuchar en toda la red local (solo para pruebas):

```bash
RUA_HOST=0.0.0.0 python server.py
```

No expongas el servidor directamente a Internet sin HTTPS, autenticación y un proxy inverso.

## Funciones incluidas
- PWA adaptable, con service worker.
- Base SQLite persistente.
- API pública `GET /api/events`.
- Estado del servidor `GET /api/health`.
- RSS automático `GET /feed.xml`.
- Alta y actualización protegida `POST /api/events`.
- Detección de duplicados por artista, ciudad, fecha y sala.
- Validación estricta de ciudades y estilos acordados.

## Añadir eventos por JSON

Configura primero un token propio:

```bash
export RUA_ADMIN_TOKEN='pon-aqui-un-token-largo-y-aleatorio'
python server.py
```

En otra terminal, importa un JSON:

```bash
curl -X POST http://127.0.0.1:8000/api/events \
  -H "Authorization: Bearer pon-aqui-un-token-largo-y-aleatorio" \
  -H "Content-Type: application/json" \
  --data-binary @eventos-ejemplo.json
```

También puedes importar directamente desde archivo, sin API:

```bash
python server.py import eventos-ejemplo.json
```

El JSON de ejemplo contiene datos ficticios de plantilla. No es un evento real; cámbialo antes de importarlo.

## Campos permitidos
- `artist`: artista (obligatorio)
- `city`: `Ourense`, `Vigo` o `Santiago de Compostela` (obligatorio)
- `date`: fecha `YYYY-MM-DD` (obligatorio)
- `style`: `Rap`, `Trap`, `Drill`, `Underground` o `Rap gallego` (obligatorio)
- `venue`, `type`, `status`, `source`, `source_url`, `ticket_url`, `announced_at`, `notes`

Tipos: `Concierto`, `Sesión / fiesta`, `Festival`.
Estados: `confirmed`, `announced`, `unverified`.

## Estado de esta entrega
El backend y el RSS ya funcionan localmente, pero todavía no hay conectores automáticos a agendas/plataformas ni notificaciones push. Esas son las siguientes fases. La app no incluye eventos reales de demostración para evitar confusiones.
