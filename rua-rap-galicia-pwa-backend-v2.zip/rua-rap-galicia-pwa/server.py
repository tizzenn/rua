#!/usr/bin/env python3
"""Rúa backend: SQLite, JSON API and RSS feed. Python standard library only."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from datetime import date, datetime, timezone
import sqlite3, json, os, hashlib, html, re, sys

ROOT = Path(__file__).resolve().parent
DB = Path(os.environ.get("RUA_DB", ROOT / "rua.sqlite3"))
HOST = os.environ.get("RUA_HOST", "127.0.0.1")
PORT = int(os.environ.get("RUA_PORT", "8000"))
ADMIN_TOKEN = os.environ.get("RUA_ADMIN_TOKEN", "cambia-este-token")
CITIES = {"Ourense", "Vigo", "Santiago de Compostela"}
STYLES = {"Rap", "Trap", "Drill", "Underground", "Rap gallego"}
TYPES = {"Concierto", "Sesión / fiesta", "Festival"}
STATUSES = {"confirmed", "announced", "unverified"}

def connect():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS events (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          fingerprint TEXT NOT NULL UNIQUE,
          artist TEXT NOT NULL,
          city TEXT NOT NULL,
          venue TEXT NOT NULL DEFAULT '',
          date TEXT NOT NULL,
          style TEXT NOT NULL,
          type TEXT NOT NULL DEFAULT 'Concierto',
          status TEXT NOT NULL DEFAULT 'announced',
          source TEXT NOT NULL DEFAULT '',
          source_url TEXT NOT NULL DEFAULT '',
          ticket_url TEXT NOT NULL DEFAULT '',
          announced_at TEXT NOT NULL DEFAULT '',
          notes TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )""")
        db.execute("CREATE INDEX IF NOT EXISTS idx_events_date ON events(date)")

def fingerprint(event):
    parts = [event["artist"], event["city"], event["date"], event.get("venue","")]
    normalized = "|".join(re.sub(r"\s+"," ",p.strip().lower()) for p in parts)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()

def validate_event(data):
    if not isinstance(data, dict):
        raise ValueError("El evento debe ser un objeto JSON.")
    required = ("artist", "city", "date", "style")
    for key in required:
        if not isinstance(data.get(key), str) or not data[key].strip():
            raise ValueError(f"Falta el campo obligatorio: {key}")
    event = {k: str(data.get(k, "")).strip() for k in (
        "artist","city","venue","date","style","type","status","source",
        "source_url","ticket_url","announced_at","notes"
    )}
    if event["city"] not in CITIES:
        raise ValueError("Ciudad no permitida. Solo Ourense, Vigo o Santiago de Compostela.")
    if event["style"] not in STYLES:
        raise ValueError("Estilo no permitido.")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", event["date"]):
        raise ValueError("La fecha debe tener formato YYYY-MM-DD.")
    date.fromisoformat(event["date"])
    if not event["type"]: event["type"] = "Concierto"
    if event["type"] not in TYPES: raise ValueError("Tipo de evento no permitido.")
    if not event["status"]: event["status"] = "announced"
    if event["status"] not in STATUSES: raise ValueError("Estado no válido.")
    for key in ("source_url","ticket_url"):
        if event[key] and not event[key].startswith(("https://","http://")):
            raise ValueError(f"{key} debe ser una URL http(s).")
    return event

def upsert_event(data):
    event = validate_event(data)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    fp = fingerprint(event)
    with connect() as db:
        old = db.execute("SELECT id FROM events WHERE fingerprint=?", (fp,)).fetchone()
        if old:
            db.execute("""UPDATE events SET artist=?,city=?,venue=?,date=?,style=?,type=?,status=?,
              source=?,source_url=?,ticket_url=?,announced_at=?,notes=?,updated_at=? WHERE fingerprint=?""",
              (event["artist"],event["city"],event["venue"],event["date"],event["style"],event["type"],
               event["status"],event["source"],event["source_url"],event["ticket_url"],
               event["announced_at"],event["notes"],now,fp))
            return old["id"], False
        cur = db.execute("""INSERT INTO events
          (fingerprint,artist,city,venue,date,style,type,status,source,source_url,ticket_url,announced_at,notes,created_at,updated_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          (fp,event["artist"],event["city"],event["venue"],event["date"],event["style"],event["type"],
           event["status"],event["source"],event["source_url"],event["ticket_url"],event["announced_at"],
           event["notes"],now,now))
        return cur.lastrowid, True

def get_events():
    with connect() as db:
        rows = db.execute("SELECT * FROM events WHERE date >= ? ORDER BY date, artist", (date.today().isoformat(),)).fetchall()
        return [dict(r) for r in rows]

def rss_feed(events):
    items=[]
    for e in events:
        title=f'{e["artist"]} — {e["city"]} ({e["date"]})'
        desc=f'{e["style"]} · {e["type"]} · {e["venue"]} · Estado: {e["status"]}. Fuente: {e["source"]}'
        link=e["source_url"] or e["ticket_url"] or "https://example.invalid/"
        guid=f'urn:rua:event:{e["fingerprint"]}'
        items.append(f"<item><title>{html.escape(title)}</title><description>{html.escape(desc)}</description><link>{html.escape(link)}</link><guid isPermaLink=\"false\">{guid}</guid><pubDate>{html.escape(e['updated_at'])}</pubDate></item>")
    now=datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    return ('<?xml version="1.0" encoding="UTF-8"?>'
      '<rss version="2.0"><channel><title>Rúa — Rap en Galicia</title>'
      '<link>https://example.invalid/</link><description>Agenda de rap, trap, drill y underground en Ourense, Vigo y Santiago de Compostela.</description>'
      f'<lastBuildDate>{now}</lastBuildDate>{"".join(items)}</channel></rss>')

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(ROOT),**kwargs)
    def send_json(self, code, payload):
        body=json.dumps(payload,ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(body))); self.send_header("Cache-Control","no-store")
        self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        path=urlparse(self.path).path
        if path=="/api/health":
            return self.send_json(200,{"ok":True,"service":"rua","database":str(DB.name)})
        if path=="/api/events":
            events=get_events()
            return self.send_json(200,{"events":events,"count":len(events)})
        if path=="/feed.xml":
            body=rss_feed(get_events()).encode()
            self.send_response(200); self.send_header("Content-Type","application/rss+xml; charset=utf-8")
            self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body); return
        return super().do_GET()
    def do_POST(self):
        if urlparse(self.path).path!="/api/events":
            return self.send_json(404,{"error":"Ruta no encontrada."})
        token=self.headers.get("Authorization","").removeprefix("Bearer ").strip()
        if not ADMIN_TOKEN or ADMIN_TOKEN=="cambia-este-token" or token!=ADMIN_TOKEN:
            return self.send_json(403,{"error":"Configura RUA_ADMIN_TOKEN y envía Authorization: Bearer <token>."})
        try:
            length=int(self.headers.get("Content-Length","0"))
            if length<=0 or length>1000000: raise ValueError("Tamaño de petición no válido.")
            data=json.loads(self.rfile.read(length))
            batch=data if isinstance(data,list) else [data]
            if len(batch)>200: raise ValueError("Máximo 200 eventos por petición.")
            results=[upsert_event(item) for item in batch]
            return self.send_json(201,{"inserted":sum(1 for _,created in results if created),
                "updated":sum(1 for _,created in results if not created),"ids":[i for i,_ in results]})
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            return self.send_json(400,{"error":str(exc)})
    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))

def main():
    init_db()
    if len(sys.argv)>1 and sys.argv[1]=="import":
        if len(sys.argv)<3: print("Uso: python server.py import eventos.json"); raise SystemExit(2)
        data=json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
        batch=data if isinstance(data,list) else [data]
        for item in batch:
            event_id,created=upsert_event(item)
            print(("Añadido" if created else "Actualizado"), event_id, item.get("artist"))
        return
    server=ThreadingHTTPServer((HOST,PORT),Handler)
    print(f"Rúa escuchando en http://{HOST}:{PORT}")
    print(f"RSS: http://{HOST}:{PORT}/feed.xml")
    print("Ctrl+C para detener.")
    try: server.serve_forever()
    except KeyboardInterrupt: print("\\nCerrando servidor…")
    finally: server.server_close()

if __name__=="__main__":
    main()
