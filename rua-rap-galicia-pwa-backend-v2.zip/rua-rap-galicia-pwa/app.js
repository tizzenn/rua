const $ = id => document.getElementById(id);
let events = [];
let apiOnline = false;

const fmt = date => {
  const d=new Date(date+"T12:00:00");
  return {day:d.toLocaleDateString("es-ES",{day:"2-digit"}),month:d.toLocaleDateString("es-ES",{month:"short"}).replace(".","").toUpperCase()};
};
const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

function render(){
  const city=$("cityFilter").value, style=$("styleFilter").value, type=$("typeFilter").value, q=$("searchInput").value.trim().toLowerCase();
  const filtered=events.filter(e=>(city==="Todas"||e.city===city)&&(style==="Todos"||e.style===style)&&(type==="Todos"||e.type===type)&&[e.artist,e.city,e.venue,e.style].join(" ").toLowerCase().includes(q));
  $("eventCount").textContent=`${filtered.length} ${filtered.length===1?"evento":"eventos"}`;
  const root=$("eventsList");
  if(!filtered.length){
    root.innerHTML='<div class="empty"><strong>No hay eventos con esos filtros.</strong><p>Cuando incorporemos nuevos anuncios, aparecerán aquí automáticamente.</p></div>';
    return;
  }
  root.innerHTML=filtered.map(e=>{
    const d=fmt(e.date);
    const source=e.source_url
      ? `<a class="source" href="${escapeHTML(e.source_url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(e.source||"Ver fuente")} ↗</a>`
      : `<span class="source">${escapeHTML(e.source||"Fuente pendiente")}</span>`;
    const ticket=e.ticket_url
      ? `<a class="ticket-link" href="${escapeHTML(e.ticket_url)}" target="_blank" rel="noopener noreferrer">ENTRADAS ↗</a>` : "";
    const status=e.status==="confirmed"?"CONFIRMADO":e.status==="unverified"?"POR CONFIRMAR":"ANUNCIO";
    return `<article class="event-card"><div class="datebox"><strong>${d.day}</strong><span>${d.month}</span></div><div class="event-info"><div class="tags"><span class="tag">${escapeHTML(e.style)}</span><span class="tag">${escapeHTML(e.type)}</span><span class="tag ${e.status==="confirmed"?"confirmed":""}">${status}</span></div><h3>${escapeHTML(e.artist)}</h3><div class="meta">${escapeHTML(e.city)} · ${escapeHTML(e.venue||"Sala por anunciar")}</div>${source}${ticket}</div></article>`;
  }).join("");
}
async function loadEvents(){
  try{
    const response=await fetch("./api/events",{headers:{"Accept":"application/json"}});
    if(!response.ok)throw new Error("API no disponible");
    const data=await response.json();
    events=data.events||[];
    apiOnline=true;
    $("apiStatus").textContent="DATOS CONECTADOS";
    $("apiStatus").classList.add("online");
  }catch(err){
    events=[];
    apiOnline=false;
    $("apiStatus").textContent="SERVIDOR DESCONECTADO";
    $("apiStatus").classList.remove("online");
  }
  render();
}
["cityFilter","styleFilter","typeFilter","searchInput"].forEach(id=>$(id).addEventListener("input",render));
loadEvents();
let deferredPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("installBtn").hidden=false;});
$("installBtn").addEventListener("click",async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("installBtn").hidden=true;});
if("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
